import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';
import './AddonsPage.css';

// Sample books and their popularity (number of issues)
const books = [
  { id: 1, title: "The Great Gatsby", issues: 44 },
  { id: 2, title: "To Kill a Mockingbird", issues: 30 },
  { id: 3, title: "1984", issues: 25 },
  { id: 4, title: "Pride and Prejudice", issues: 15 },
];

export default function AddonsPage() {
  return (
    <div className="addons-container">
      <h2>Library Add-ons & Stats</h2>

      <div className="addon-card">
        <h3>Quick Tools</h3>
        <button>Search Library Catalog</button>
        <button>View Due Dates</button>
      </div>

      <div className="addon-card">
        <h3>Recommended Books</h3>
        <ul>
          {books.map(book => (
            <li key={book.id}>{book.title} by {book.author}</li>
          ))}
        </ul>
      </div>

      <div className="addon-card">
        <h3>Book Popularity Stats</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={books} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="title" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="issues" fill="#3b82f6" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
