import React, { useState } from 'react';

export default function ReturnPage() {
  const [bookId, setBookId] = useState('');

  const handleReturn = (e) => {
    e.preventDefault();
    alert(`Book with ID ${bookId} returned successfully!`);
    setBookId('');
  };

  return (
    <div className="card-container">
      <h2 className="text-xl font-bold mb-4">Return Book</h2>
      <form onSubmit={handleReturn}>
        <input
          type="text"
          placeholder="Enter Book ID"
          value={bookId}
          onChange={(e) => setBookId(e.target.value)}
          className="w-full p-3 border rounded mb-4"
        />
        <button
          type="submit"
          className="w-full bg-red-600 hover:bg-red-500 text-white py-3 rounded"
        >
          Return Book
        </button>
      </form>
    </div>
  );
}
