import React, { useState } from 'react';
import './BooksPage.css';

// Sample books data
const books = [
  {
    id: 1,
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    image: "https://images-na.ssl-images-amazon.com/images/I/81af+MCATTL.jpg",
  },
  {
    id: 2,
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    image: "https://images-na.ssl-images-amazon.com/images/I/81OdwZ23JkL.jpg",
  },
  {
    id: 3,
    title: "1984",
    author: "George Orwell",
    image: "https://images-na.ssl-images-amazon.com/images/I/71kxa1-0mfL.jpg",
  },
  {
    id: 4,
    title: "Pride and Prejudice",
    author: "Jane Austen",
    image: "https://images-na.ssl-images-amazon.com/images/I/91HHqVTAJQL.jpg",
  },
];

export default function BooksPage() {
  const [cart, setCart] = useState([]);

  const addToCart = (book) => {
    if (!cart.includes(book.id)) {
      setCart([...cart, book.id]);
      alert(`${book.title} added to cart!`);
    }
  };

  const issueBook = (book) => {
    alert(`${book.title} issued!`);
  };

  const returnBook = (book) => {
    alert(`${book.title} returned!`);
  };

  return (
    <div className="books-container">
      <h2>Books Available</h2>
      <div className="books-grid">
        {books.map((book) => (
          <div className="book-card" key={book.id}>
            {/* Add to Cart Emoji on top-right */}
            <span className="cart-icon" onClick={() => addToCart(book)}>🛒</span>

            <img src={book.image} alt={book.title} />
            <h3>{book.title}</h3>
            <p>{book.author}</p>
            <button onClick={() => issueBook(book)}>Issue Book</button>
            <button onClick={() => returnBook(book)}>Return Book</button>
          </div>
        ))}
      </div>
    </div>
  );
}
