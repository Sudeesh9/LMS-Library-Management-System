import React from 'react';

export default function CartPage() {
  return (
    <div className="card-container">
      <h2 className="text-xl font-bold mb-4">Cart</h2>
      <p>Your selected books for checkout will appear here.</p>
    </div>
  );
}
