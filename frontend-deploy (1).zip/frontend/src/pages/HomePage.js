import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.css';

export default function HomePage() {
  // Dummy summary data
  const summary = {
    totalBooks: 120,
    issuedBooks: 35,
    availableBooks: 85,
  };

  return (
    <div className="home-container">
      <h1>📚 Welcome to My Library</h1>

      <div className="summary-cards">
        <div className="card">
          <h2>{summary.totalBooks}</h2>
          <p>Total Books</p>
        </div>
        <div className="card">
          <h2>{summary.issuedBooks}</h2>
          <p>Issued Books</p>
        </div>
        <div className="card">
          <h2>{summary.availableBooks}</h2>
          <p>Available Books</p>
        </div>
      </div>

      <h2>Quick Links</h2>
      <div className="quick-links">
        <Link to="/books" className="link-card">Browse Books</Link>
        <Link to="/cart" className="link-card">Cart</Link>
        <Link to="/wishlist" className="link-card">Wishlist</Link>
        <Link to="/profile" className="link-card">Profile</Link>
      </div>
    </div>
  );
}
