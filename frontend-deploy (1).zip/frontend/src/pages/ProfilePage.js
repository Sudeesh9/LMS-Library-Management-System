import React from 'react';
import './ProfilePage.css';

export default function ProfilePage() {
  // Mock user data
  const user = {
    username: 'John Doe',
    email: 'johndoe@example.com',
    contact: '9876543210',
    usertype: 'Student',
  };

  return (
    <div className="profile-container">
      <h2>My Profile</h2>
      <div className="profile-card">
        <p><strong>Username:</strong> {user.username}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Contact:</strong> {user.contact}</p>
        <p><strong>User Type:</strong> {user.usertype}</p>
      </div>
    </div>
  );
}
