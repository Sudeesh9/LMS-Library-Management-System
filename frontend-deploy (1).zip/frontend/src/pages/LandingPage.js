import React from 'react';
import { useNavigate } from 'react-router-dom';
import './LandingPage.css';

export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="landing-page">
      <div className="overlay">
        <h1>Welcome to 📚 My Library</h1>
        <p>Your digital library management system</p>
        <button onClick={() => navigate('/login')}>Get Started</button>
      </div>
    </div>
  );
}
