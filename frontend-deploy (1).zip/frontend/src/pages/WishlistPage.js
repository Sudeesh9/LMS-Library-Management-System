import React from 'react';

export default function WishlistPage() {
  return (
    <div className="card-container">
      <h2 className="text-xl font-bold mb-4">Wishlist</h2>
      <p>Your saved books will be shown here.</p>
    </div>
  );
}
