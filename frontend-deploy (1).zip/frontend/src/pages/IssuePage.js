import React, { useState } from 'react';

export default function IssuePage() {
  const [bookId, setBookId] = useState('');

  const handleIssue = (e) => {
    e.preventDefault();
    alert(`Book with ID ${bookId} issued successfully!`);
    setBookId('');
  };

  return (
    <div className="card-container">
      <h2 className="text-xl font-bold mb-4">Issue Book</h2>
      <form onSubmit={handleIssue}>
        <input
          type="text"
          placeholder="Enter Book ID"
          value={bookId}
          onChange={(e) => setBookId(e.target.value)}
          className="w-full p-3 border rounded mb-4"
        />
        <button
          type="submit"
          className="w-full bg-green-600 hover:bg-green-500 text-white py-3 rounded"
        >
          Issue Book
        </button>
      </form>
    </div>
  );
}
