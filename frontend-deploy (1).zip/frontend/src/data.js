const data = [
  {
    id: 1,
    title: 'Wings of Fire',
    author: 'APJ Abdul Kalam',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9788173711466-L.jpg'
  },
  {
    id: 2,
    title: 'Harry Potter and the Prisoner of Azkaban',
    author: 'J.K. Rowling',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9780439136365-L.jpg'
  },
  {
    id: 3,
    title: 'The Alchemist',
    author: 'Paulo Coelho',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9780061122415-L.jpg'
  },
  {
    id: 4,
    title: 'Rich Dad Poor Dad',
    author: 'Robert Kiyosaki',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9781612680019-L.jpg'
  },
  {
    id: 5,
    title: 'Think and Grow Rich',
    author: 'Napoleon Hill',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9780449214923-L.jpg'
  },
  {
    id: 6,
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9780060935467-L.jpg'
  },
  {
    id: 7,
    title: 'The Hobbit',
    author: 'J.R.R. Tolkien',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9780618260300-L.jpg'
  },
  {
    id: 8,
    title: 'Pride and Prejudice',
    author: 'Jane Austen',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9780141439518-L.jpg'
  },
  {
    id: 9,
    title: 'Catcher in the Rye',
    author: 'J.D. Salinger',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9780316769488-L.jpg'
  },
  {
    id: 10,
    title: '1984',
    author: 'George Orwell',
    price: 0,
    available: true,
    image: 'https://covers.openlibrary.org/b/isbn/9780451524935-L.jpg'
  }
];

export default data;
