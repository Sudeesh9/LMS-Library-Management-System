const sampleBooks = [
  { id: 1, title: "Wings of Fire", author: "APJ Abdul Kalam", available: true, image: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=400&q=80" },
  { id: 2, title: "Harry Potter", author: "J.K. Rowling", available: true, image: "https://images.unsplash.com/photo-1606326550232-3c86c6c2f594?auto=format&fit=crop&w=400&q=80" },
  { id: 3, title: "The Alchemist", author: "Paulo Coelho", available: true, image: "https://images.unsplash.com/photo-1590608897129-79a2c2c63e8d?auto=format&fit=crop&w=400&q=80" },
  { id: 4, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", available: true, image: "https://images.unsplash.com/photo-1544937754-2d8f5756f5ff?auto=format&fit=crop&w=400&q=80" },
  { id: 5, title: "Think and Grow Rich", author: "Napoleon Hill", available: true, image: "https://images.unsplash.com/photo-1581091870620-15164aef5c2d?auto=format&fit=crop&w=400&q=80" },
  { id: 6, title: "To Kill a Mockingbird", author: "Harper Lee", available: true, image: "https://images.unsplash.com/photo-1576108069541-2799b6e8f3bb?auto=format&fit=crop&w=400&q=80" },
  { id: 7, title: "The Hobbit", author: "J.R.R. Tolkien", available: true, image: "https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&w=400&q=80" },
  { id: 8, title: "Pride and Prejudice", author: "Jane Austen", available: true, image: "https://images.unsplash.com/photo-1586481071205-6215de48a80f?auto=format&fit=crop&w=400&q=80" },
  { id: 9, title: "Catcher in the Rye", author: "J.D. Salinger", available: true, image: "https://images.unsplash.com/photo-1551022375-5bcd6b0b8a2e?auto=format&fit=crop&w=400&q=80" },
  { id: 10, title: "1984", author: "George Orwell", available: true, image: "https://images.unsplash.com/photo-1581039942493-3ec0e07c0b1f?auto=format&fit=crop&w=400&q=80" }
];

export default sampleBooks;
