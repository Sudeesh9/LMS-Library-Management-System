import React from 'react';

export default function BookDetails({ book, onClose }){
  if(!book) return null;
  return (
    <div className="fixed inset-0 flex items-center justify-center modal-backdrop z-50">
      <div className="bg-white dark:bg-gray-800 p-6 rounded shadow max-w-md w-full">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-xl font-bold">{book.title}</h3>
            <p className="text-sm text-gray-500">{book.author}</p>
          </div>
          <button onClick={onClose} className="text-gray-600">✕</button>
        </div>

        <div className="mt-4 flex gap-4">
          <img src={book.image || 'https://via.placeholder.com/150x220?text=No+Image'} alt={book.title} className="w-36 h-52 object-cover rounded" onError={(e)=>{e.target.onerror=null;e.target.src='https://via.placeholder.com/150x220?text=No+Image'}} />
          <div>
            <p className="mt-1">{book.available ? '📗 Available to borrow' : '❌ Not available'}</p>
            <p className="mt-4 text-sm text-gray-600">Price: ₹{book.price || 0}</p>
            <div className="mt-6">
              <button className="px-3 py-2 bg-indigo-600 text-white rounded mr-2">Borrow</button>
              <button onClick={onClose} className="px-3 py-2 border rounded">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
