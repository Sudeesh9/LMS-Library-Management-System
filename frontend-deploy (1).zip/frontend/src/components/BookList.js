import React from 'react';
import BookCard from './BookCard';

export default function BookList({ books, onAddToCart, onDetails, toggleWishlist, wishlist }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {books.map(b => (
        <BookCard
          key={b.id}
          book={b}
          onAdd={onAddToCart}
          onDetails={onDetails}
          onToggleWish={toggleWishlist}
          wished={!!wishlist.find(x => x.id === b.id)}
        />
      ))}
    </div>
  );
}
