import React from 'react';

export default function Cart({ cart, removeFromCart }) {
  const total = cart.reduce((s, b) => s + (b.price || 0) * (b.qty || 1), 0);
  return (
    <div className="mt-6 bg-white dark:bg-gray-800 rounded p-4 shadow">
      <h4 className="font-semibold">Cart</h4>
      {cart.length === 0 ? (
        <p className="text-sm text-gray-500 mt-2">No items in cart</p>
      ) : (
        <div className="mt-2">
          {cart.map(item => (
            <div key={item.id} className="flex justify-between items-center py-2 border-b last:border-b-0">
              <div>
                <div className="font-medium">{item.title}</div>
                <div className="text-xs text-gray-500">{item.author}</div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium">₹{item.price || '0'}</div>
                <button className="text-sm text-red-500 mt-1" onClick={() => removeFromCart(item.id)}>Remove</button>
              </div>
            </div>
          ))}

          <div className="mt-3 flex justify-between font-semibold">
            <span>Total</span>
            <span>₹{total}</span>
          </div>
          <button className="w-full mt-3 bg-green-500 text-white rounded py-2">Proceed</button>
        </div>
      )}
    </div>
  );
}
