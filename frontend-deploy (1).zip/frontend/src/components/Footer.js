import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      © 2025 My Library. All rights reserved.
    </footer>
  );
}
