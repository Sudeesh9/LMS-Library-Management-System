import React, { useState } from 'react';
import './Chatbot.css';

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const toggleChat = () => setIsOpen(!isOpen);

  const getBotResponse = (text) => {
    text = text.toLowerCase();
    if (text.includes('hello') || text.includes('hi')) return 'Hello! How can I help you today?';
    if (text.includes('books')) return 'We have Java, Python, PHP, HTML, CSS, and more.';
    if (text.includes('issue')) return 'To issue a book, click the "Issue Book" button on the book page.';
    if (text.includes('return')) return 'To return a book, click the "Return Book" button on your issued books.';
    if (text.includes('cart')) return 'You can add books to your cart by clicking the 🛒 emoji on each book.';
    return "Sorry, I didn't understand that. Try asking about books, issue, return, or cart.";
  };

  const sendMessage = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    setMessages([...messages, { text: input, user: true }]);

    setTimeout(() => {
      const botReply = getBotResponse(input);
      setMessages((prev) => [...prev, { text: botReply, user: false }]);
    }, 500);

    setInput('');
  };

  return (
    <div>
      <button className="chatbot-toggle" onClick={toggleChat}>🤖</button>

      {isOpen && (
        <div className="chatbot-box">
          <div className="chatbot-header">Chat with Library Bot</div>
          <div className="chatbot-messages">
            {messages.map((msg, idx) => (
              <div key={idx} className={msg.user ? 'message user' : 'message bot'}>
                {msg.text}
              </div>
            ))}
          </div>
          <form onSubmit={sendMessage} className="chatbot-input-form">
            <input
              type="text"
              placeholder="Type a message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button type="submit">Send</button>
          </form>
        </div>
      )}
    </div>
  );
}
